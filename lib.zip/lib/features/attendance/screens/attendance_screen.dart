import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'attendance_bloc.dart';
import '../../core/models/attendance_record.dart';

class AttendanceScreen extends StatelessWidget {
  final String sessionId;

  const AttendanceScreen({Key? key, required this.sessionId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Record Attendance')),
      body: BlocProvider(
        create: (context) => AttendanceBloc(sessionId: sessionId),
        child: BlocConsumer<AttendanceBloc, AttendanceState>(
          listener: (context, state) {
            if (state is AttendanceError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(state.message)),
              );
            }
          },
          builder: (context, state) {
            if (state is AttendanceLoading) {
              return Center(child: CircularProgressIndicator());
            }

            if (state is AttendanceEmpty) {
              return Center(child: Text('No students found for this session.'));
            }

            if (state is AttendanceLoadedImpl) {
              return ListView.builder(
                itemCount: state.students.length,
                itemBuilder: (context, index) {
                  final student = state.students[index];
                  return ListTile(
                    title: Text(student.name),
                    trailing: Checkbox(
                      value: student.isPresent,
                      onChanged: (value) {
                        context.read<AttendanceBloc>().add(
                          ToggleAttendanceEvent(
                            studentId: student.id,
                            isPresent: value ?? false,
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            }

            return Center(child: Text('Loading...'));
          },
        ),
      ),
      floatingActionButton: BlocBuilder<AttendanceBloc, AttendanceState>(
        builder: (context, state) {
          if (state is AttendanceLoadedImpl && state.syncStatus == 'syncing') {
            return FloatingActionButton(
              onPressed: () {},
              child: CircularProgressIndicator(),
            );
          }
          return FloatingActionButton(
            onPressed: () {
              context.read<AttendanceBloc>().add(SyncAttendanceEvent());
            },
            child: Icon(Icons.sync),
          );
        },
      ),
    );
  }
}

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/models/attendance_record.dart';
import 'attendance_event.dart';
import 'attendance_state.dart';

class AttendanceBloc extends Bloc<AttendanceEvent, AttendanceState> {
  final String sessionId;
  final Box<AttendanceRecord> _attendanceBox;
  final FirebaseFirestore _firestore;

  AttendanceBloc({
    required this.sessionId,
    required Box<AttendanceRecord> attendanceBox,
    required FirebaseFirestore firestore,
  })  : _attendanceBox = attendanceBox,
        _firestore = firestore,
        super(AttendanceLoading()) {
    on<LoadAttendanceEvent>(_onLoadAttendance);
    on<ToggleAttendanceEvent>(_onToggleAttendance);
    on<SyncAttendanceEvent>(_onSyncAttendance);
  }

  Future<void> _onLoadAttendance(
    LoadAttendanceEvent event,
    Emitter<AttendanceState> emit,
  ) async {
    emit(AttendanceLoading());

    try {
      final records = _attendanceBox.values
          .where((record) => record.sessionId == sessionId)
          .toList();

      if (records.isEmpty) {
        emit(AttendanceEmpty());
      } else {
        emit(AttendanceLoadedImpl(students: records));
      }
    } catch (e) {
      emit(AttendanceError(message: e.toString()));
    }
  }

  Future<void> _onToggleAttendance(
    ToggleAttendanceEvent event,
    Emitter<AttendanceState> emit,
  ) async {
    try {
      // Generate a stable record ID
      final recordId = '${sessionId}_${event.studentId}';

      // Check if record already exists locally
      var record = _attendanceBox.get(recordId);

      if (record == null) {
        record = AttendanceRecord(
          id: recordId,
          sessionId: sessionId,
          studentId: event.studentId,
          isPresent: event.isPresent,
          timestamp: DateTime.now().toIso8601String(),
          syncStatus: 'pending',
        );
      } else {
        record = record.copyWith(
          isPresent: event.isPresent,
          timestamp: DateTime.now().toIso8601String(),
          syncStatus: 'pending',
        );
      }

      // Save locally first (offline-first)
      await _attendanceBox.put(recordId, record);

      // Emit updated state
      final records = _attendanceBox.values
          .where((r) => r.sessionId == sessionId)
          .toList();

      emit(AttendanceLoadedImpl(students: records));

      // Trigger sync if online
      add(SyncAttendanceEvent());
    } catch (e) {
      emit(AttendanceError(message: 'Failed to update attendance: $e'));
    }
  }

  Future<void> _onSyncAttendance(
    SyncAttendanceEvent event,
    Emitter<AttendanceState> emit,
  ) async {
    try {
      // Get all pending records for this session
      final pendingRecords = _attendanceBox.values
          .where((record) =>
              record.sessionId == sessionId && record.syncStatus == 'pending')
          .toList();

      if (pendingRecords.isEmpty) return;

      // Update UI to show syncing state
      final allRecords = _attendanceBox.values
          .where((r) => r.sessionId == sessionId)
          .toList();

      emit(AttendanceLoadedImpl(
        students: allRecords,
        syncStatus: 'syncing',
      ));

      // Use batch write for efficiency
      final batch = _firestore.batch();
      final collectionRef = _firestore.collection('attendance');

      for (var record in pendingRecords) {
        final docRef = collectionRef.doc(record.id);
        batch.set(docRef, {
          'sessionId': record.sessionId,
          'studentId': record.studentId,
          'isPresent': record.isPresent,
          'timestamp': record.timestamp,
          'syncStatus': 'synced',
          'lastModified': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }

      await batch.commit();

      // Update local records to synced status
      for (var record in pendingRecords) {
        final updatedRecord = record.copyWith(syncStatus: 'synced');
        await _attendanceBox.put(record.id, updatedRecord);
      }

      // Emit final state
      final syncedRecords = _attendanceBox.values
          .where((r) => r.sessionId == sessionId)
          .toList();

      emit(AttendanceLoadedImpl(
        students: syncedRecords,
        syncStatus: 'synced',
      ));
    } catch (e) {
      // Mark as failed for retry
      final failedRecords = _attendanceBox.values
          .where((r) => r.sessionId == sessionId && r.syncStatus == 'pending')
          .toList();

      for (var record in failedRecords) {
        final updatedRecord = record.copyWith(syncStatus: 'failed');
        await _attendanceBox.put(record.id, updatedRecord);
      }

      emit(AttendanceError(
        message: 'Sync failed: $e',
        records: _attendanceBox.values
            .where((r) => r.sessionId == sessionId)
            .toList(),
      ));
    }
  }
}

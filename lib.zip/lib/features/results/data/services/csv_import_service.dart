import 'dart:io';
import 'package:csv/csv.dart';
import 'package:church_management_system/core/di/injection.dart';
import 'package:church_management_system/features/results/domain/entities/csv_import_models.dart';
import 'package:church_management_system/features/student/domain/repos/i_student_repository.dart';

class CsvImportService {
  Future<CsvImportBatch> parseFile({
    required String filePath,
    required String termId,
    required String termName,
  }) async {
    final file = File(filePath);
    final fileName = file.uri.pathSegments.last;
    final csvString = await file.readAsString();

    // Parse CSV
    final List<List<dynamic>> csvTable = CsvDecoder(
      dynamicTyping: true,
    ).convert(csvString);

    final List<CsvImportRow> rows = [];
    int validCount = 0;
    int invalidCount = 0;

    // Detect header (typically: studentId, studentName, score)
    int startRowIndex = 0;
    if (csvTable.isNotEmpty) {
      final firstRow = csvTable.first.map((e) => e.toString().toLowerCase()).toList();
      if (firstRow.contains('studentid') || firstRow.contains('id') || firstRow.contains('score')) {
        startRowIndex = 1; // skip header
      }
    }

    for (int i = startRowIndex; i < csvTable.length; i++) {
      final csvRow = csvTable[i];
      if (csvRow.isEmpty || (csvRow.length == 1 && csvRow[0].toString().trim().isEmpty)) {
        continue; // skip empty lines
      }

      final int rowIndex = i + 1;

      // Extract columns
      final studentIdStr = csvRow.isNotEmpty ? csvRow[0].toString().trim() : '';
      final studentNameStr = csvRow.length > 1 ? csvRow[1].toString().trim() : null;
      final scoreRaw = csvRow.length > 2 ? csvRow[2] : null;

      // Validate studentId
      if (studentIdStr.isEmpty) {
        rows.add(CsvImportRow(
          rowIndex: rowIndex,
          studentId: '',
          studentName: studentNameStr,
          termId: termId,
          score: 0,
          isValid: false,
          validationError: 'معرف الطالب (studentId) فارغ.',
        ));
        invalidCount++;
        continue;
      }

      // Validate score
      double score = 0;
      bool isScoreValid = true;
      String? scoreError;

      if (scoreRaw == null) {
        isScoreValid = false;
        scoreError = 'عمود الدرجة مفقود.';
      } else {
        final parsedScore = double.tryParse(scoreRaw.toString());
        if (parsedScore == null) {
          isScoreValid = false;
          scoreError = 'الدرجة غير صالحة: "${scoreRaw.toString()}".';
        } else if (parsedScore < 0 || parsedScore > 100) {
          isScoreValid = false;
          scoreError = 'الدرجة يجب أن تكون بين 0 و 100.';
        } else {
          score = parsedScore;
        }
      }

      if (!isScoreValid) {
        rows.add(CsvImportRow(
          rowIndex: rowIndex,
          studentId: studentIdStr,
          studentName: studentNameStr,
          termId: termId,
          score: 0,
          isValid: false,
          validationError: scoreError,
        ));
        invalidCount++;
        continue;
      }

      // Validate student exists in repository/cache
      bool studentExists = false;
      try {
        final student = await getIt<IStudentRepository>().getStudentById(studentIdStr);
        studentExists = student != null;
      } catch (_) {
        // Fallback or ignore
      }

      if (!studentExists) {
        rows.add(CsvImportRow(
          rowIndex: rowIndex,
          studentId: studentIdStr,
          studentName: studentNameStr,
          termId: termId,
          score: score,
          isValid: false,
          validationError: 'المخدوم غير موجود في النظام أو كود الطالب خاطئ.',
        ));
        invalidCount++;
        continue;
      }

      // If all checks pass
      rows.add(CsvImportRow(
        rowIndex: rowIndex,
        studentId: studentIdStr,
        studentName: studentNameStr ?? '',
        termId: termId,
        score: score,
        isValid: true,
      ));
      validCount++;
    }

    return CsvImportBatch(
      termId: termId,
      termName: termName,
      rows: rows,
      validCount: validCount,
      invalidCount: invalidCount,
      fileName: fileName,
    );
  }
}

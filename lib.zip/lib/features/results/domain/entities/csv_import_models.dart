class CsvImportRow {
  final int rowIndex;
  final String studentId;
  final String? studentName;
  final String termId;
  final double score;
  final bool isValid;
  final String? validationError;

  const CsvImportRow({
    required this.rowIndex,
    required this.studentId,
    this.studentName,
    required this.termId,
    required this.score,
    required this.isValid,
    this.validationError,
  });
}

class CsvImportBatch {
  final String termId;
  final String termName;
  final List<CsvImportRow> rows;
  final int validCount;
  final int invalidCount;
  final String fileName;

  const CsvImportBatch({
    required this.termId,
    required this.termName,
    required this.rows,
    required this.validCount,
    required this.invalidCount,
    required this.fileName,
  });
}

class BulkOperationResult {
  final int successCount;
  final int failureCount;
  final List<String> errors;

  const BulkOperationResult({
    required this.successCount,
    required this.failureCount,
    required this.errors,
  });
}

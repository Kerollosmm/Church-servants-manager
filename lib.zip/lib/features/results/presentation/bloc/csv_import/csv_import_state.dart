import 'package:church_management_system/features/results/domain/entities/csv_import_models.dart';
import 'package:equatable/equatable.dart';

abstract class CsvImportState extends Equatable {
  const CsvImportState();

  @override
  List<Object?> get props => [];
}

class CsvImportInitial extends CsvImportState {}

class CsvImportParsing extends CsvImportState {}

class CsvImportPreviewReady extends CsvImportState {
  final CsvImportBatch batch;

  const CsvImportPreviewReady({required this.batch});

  @override
  List<Object?> get props => [batch];
}

class CsvImportPublishing extends CsvImportState {
  const CsvImportPublishing();
}

class CsvImportSuccess extends CsvImportState {
  final BulkOperationResult result;

  const CsvImportSuccess({required this.result});

  @override
  List<Object?> get props => [result];
}

class CsvImportFailure extends CsvImportState {
  final String message;

  const CsvImportFailure({required this.message});

  @override
  List<Object?> get props => [message];
}

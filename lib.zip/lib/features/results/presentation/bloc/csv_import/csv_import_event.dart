import 'package:equatable/equatable.dart';

abstract class CsvImportEvent extends Equatable {
  const CsvImportEvent();

  @override
  List<Object?> get props => [];
}

class FileSelected extends CsvImportEvent {
  final String filePath;
  final String termId;
  final String termName;

  const FileSelected({
    required this.filePath,
    required this.termId,
    required this.termName,
  });

  @override
  List<Object?> get props => [filePath, termId, termName];
}

class PublishResults extends CsvImportEvent {
  const PublishResults();
}

class ResetImport extends CsvImportEvent {
  const ResetImport();
}

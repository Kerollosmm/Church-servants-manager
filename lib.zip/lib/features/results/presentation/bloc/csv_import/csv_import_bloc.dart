import 'dart:async';
import 'package:church_management_system/features/results/domain/repos/i_results_repository.dart';
import 'package:church_management_system/features/results/data/services/csv_import_service.dart';
import 'package:church_management_system/features/results/presentation/bloc/csv_import/csv_import_event.dart';
import 'package:church_management_system/features/results/presentation/bloc/csv_import/csv_import_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CsvImportBloc extends Bloc<CsvImportEvent, CsvImportState> {
  final IResultsRepository _resultsRepository;
  final CsvImportService _csvImportService;

  CsvImportBloc({
    required IResultsRepository resultsRepository,
    CsvImportService? csvImportService,
  })  : _resultsRepository = resultsRepository,
        _csvImportService = csvImportService ?? CsvImportService(),
        super(CsvImportInitial()) {
    on<FileSelected>(_onFileSelected);
    on<PublishResults>(_onPublishResults);
    on<ResetImport>(_onResetImport);
  }

  Future<void> _onFileSelected(
    FileSelected event,
    Emitter<CsvImportState> emit,
  ) async {
    emit(CsvImportParsing());
    try {
      final batch = await _csvImportService.parseFile(
        filePath: event.filePath,
        termId: event.termId,
        termName: event.termName,
      );
      emit(CsvImportPreviewReady(batch: batch));
    } catch (e) {
      emit(CsvImportFailure(message: 'فشل تحليل الملف: ${e.toString()}'));
    }
  }

  Future<void> _onPublishResults(
    PublishResults event,
    Emitter<CsvImportState> emit,
  ) async {
    if (state is CsvImportPreviewReady) {
      final currentBatch = (state as CsvImportPreviewReady).batch;
      emit(const CsvImportPublishing());
      try {
        final result = await _resultsRepository.publishBatchResults(currentBatch);
        emit(CsvImportSuccess(result: result));
      } catch (e) {
        emit(CsvImportFailure(message: 'فشل نشر الدرجات: ${e.toString()}'));
      }
    }
  }

  void _onResetImport(
    ResetImport event,
    Emitter<CsvImportState> emit,
  ) {
    emit(CsvImportInitial());
  }
}

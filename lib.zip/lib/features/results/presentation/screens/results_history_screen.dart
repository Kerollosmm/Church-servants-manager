import 'package:church_management_system/core/di/injection.dart';
import 'package:church_management_system/features/auth/data/models/auth_user.dart';
import 'package:church_management_system/features/results/presentation/bloc/results_bloc.dart';
import 'package:church_management_system/features/results/presentation/bloc/results_event.dart';
import 'package:church_management_system/features/results/presentation/bloc/results_state.dart';
import 'package:church_management_system/features/results/presentation/widgets/result_score_card.dart';
import 'package:church_management_system/features/results/data/models/term_model.dart';
import 'package:church_management_system/features/results/presentation/widgets/term_selector_widget.dart';
import 'package:church_management_system/shared/widgets/offline_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ResultsHistoryScreen extends StatefulWidget {
  final AuthUser actor;
  final String studentId;
  final String studentName;

  const ResultsHistoryScreen({
    super.key,
    required this.actor,
    required this.studentId,
    required this.studentName,
  });

  @override
  State<ResultsHistoryScreen> createState() => _ResultsHistoryScreenState();
}

class _ResultsHistoryScreenState extends State<ResultsHistoryScreen> {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return BlocProvider(
      create: (context) => ResultsBloc(resultsRepository: getIt())
        ..add(ResultsLoadForStudentRequested(studentId: widget.studentId)),
      child: Scaffold(
        appBar: AppBar(
          title: Text('نتائج ${widget.studentName}'),
          centerTitle: true,
        ),
        body: Column(
          children: [
            const OfflineIndicator(),
            Expanded(
              child: BlocBuilder<ResultsBloc, ResultsState>(
                builder: (context, state) {
                  if (state is ResultsLoading) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  if (state is ResultsError) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.error_outline,
                              color: Colors.redAccent,
                              size: 48,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'حدث خطأ أثناء تحميل النتائج',
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              state.message,
                              textAlign: TextAlign.center,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: theme.hintColor,
                              ),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: () {
                                context.read<ResultsBloc>().add(
                                      ResultsLoadForStudentRequested(
                                        studentId: widget.studentId,
                                      ),
                                    );
                              },
                              child: const Text('إعادة المحاولة'),
                            ),
                          ],
                        ),
                      ),
                    );
                  }

                  if (state is ResultsLoaded) {
                    final allResults = state.results;
                    final filteredResults = state.selectedTermId == null
                        ? allResults
                        : allResults.where((r) => r.termId == state.selectedTermId).toList();

                    return RefreshIndicator(
                      onRefresh: () async {
                        context.read<ResultsBloc>().add(
                              ResultsLoadForStudentRequested(
                                studentId: widget.studentId,
                              ),
                            );
                      },
                      child: CustomScrollView(
                        slivers: [
                          // Filter Header
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: TermSelectorWidget(
                                terms: state.terms,
                                selectedTermId: state.selectedTermId,
                                onChanged: (termId) {
                                  context.read<ResultsBloc>().add(
                                        TermFilterChanged(termId),
                                      );
                                },
                              ),
                            ),
                          ),
                          // Results List
                          if (filteredResults.isEmpty)
                            SliverFillRemaining(
                              hasScrollBody: false,
                              child: Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(32.0),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.assignment_outlined,
                                        size: 72,
                                        color: theme.hintColor.withOpacity(0.3),
                                      ),
                                      const SizedBox(height: 16),
                                      Text(
                                        'لا توجد نتائج مسجلة',
                                        style: theme.textTheme.titleMedium?.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: theme.hintColor,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        state.selectedTermId != null
                                            ? 'لم يتم العثور على نتائج للترم المحدد.'
                                            : 'لم يتم رصد درجات لهذا المخدوم بعد.',
                                        textAlign: TextAlign.center,
                                        style: theme.textTheme.bodyMedium?.copyWith(
                                          color: theme.hintColor.withOpacity(0.7),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          else
                            SliverList(
                              delegate: SliverChildBuilderDelegate(
                                (context, index) {
                                  final result = filteredResults[index];
                                  final term = state.terms.firstWhere(
                                    (t) => t.id == result.termId,
                                    orElse: () => TermModel(
                                      id: result.termId,
                                      name: result.termId == 'term_1'
                                          ? 'الترم الأول'
                                          : (result.termId == 'term_2'
                                              ? 'الترم الثاني'
                                              : result.termId),
                                    ),
                                  );

                                  return ResultScoreCard(
                                    result: result,
                                    termName: term.name,
                                  );
                                },
                                childCount: filteredResults.length,
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return const SizedBox.shrink();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

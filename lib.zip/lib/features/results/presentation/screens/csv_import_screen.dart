import 'package:church_management_system/core/di/injection.dart';
import 'package:church_management_system/features/auth/data/models/auth_user.dart';
import 'package:church_management_system/features/results/presentation/bloc/csv_import/csv_import_bloc.dart';
import 'package:church_management_system/features/results/presentation/bloc/csv_import/csv_import_event.dart';
import 'package:church_management_system/features/results/presentation/bloc/csv_import/csv_import_state.dart';
import 'package:church_management_system/shared/widgets/offline_indicator.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CsvImportScreen extends StatefulWidget {
  final AuthUser actor;

  const CsvImportScreen({super.key, required this.actor});

  @override
  State<CsvImportScreen> createState() => _CsvImportScreenState();
}

class _CsvImportScreenState extends State<CsvImportScreen> {
  final _formKey = GlobalKey<FormState>();
  final _termIdController = TextEditingController();
  final _termNameController = TextEditingController();

  @override
  void dispose() {
    _termIdController.dispose();
    _termNameController.dispose();
    super.dispose();
  }

  Future<void> _pickAndParseFile(BuildContext context) async {
    if (!_formKey.currentState!.validate()) return;

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );

    if (result != null && result.files.single.path != null) {
      if (mounted) {
        context.read<CsvImportBloc>().add(
              FileSelected(
                filePath: result.files.single.path!,
                termId: _termIdController.text.trim(),
                termName: _termNameController.text.trim(),
              ),
            );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return BlocProvider(
      create: (context) => CsvImportBloc(resultsRepository: getIt()),
      child: Builder(
        builder: (context) {
          return Scaffold(
            appBar: AppBar(
              title: const Text('استيراد درجات CSV'),
              centerTitle: true,
            ),
            body: Column(
              children: [
                const OfflineIndicator(),
                Expanded(
                  child: BlocConsumer<CsvImportBloc, CsvImportState>(
                    listener: (context, state) {
                      if (state is CsvImportFailure) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(state.message),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    },
                    builder: (context, state) {
                      if (state is CsvImportParsing) {
                        return const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(),
                              SizedBox(height: 16),
                              Text('جاري تحليل ملف الـ CSV...'),
                            ],
                          ),
                        );
                      }

                      if (state is CsvImportPublishing) {
                        return const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(),
                              SizedBox(height: 16),
                              Text('جاري نشر الدرجات إلى قاعدة البيانات...'),
                            ],
                          ),
                        );
                      }

                      if (state is CsvImportSuccess) {
                        return _buildSuccessWidget(state, context);
                      }

                      if (state is CsvImportPreviewReady) {
                        return _buildPreviewWidget(state, context);
                      }

                      // Default Initial/Failure state: Form to pick file
                      return SingleChildScrollView(
                        padding: const EdgeInsets.all(24.0),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              const Icon(
                                Icons.upload_file_outlined,
                                size: 80,
                                color: Colors.blueAccent,
                              ),
                              const SizedBox(height: 24),
                              Text(
                                'قم برصد درجات الطلاب دفعة واحدة عن طريق رفع ملف CSV بالصيغة المحددة.',
                                textAlign: TextAlign.center,
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: theme.hintColor,
                                ),
                              ),
                              const SizedBox(height: 32),
                              // Term ID input
                              TextFormField(
                                controller: _termIdController,
                                decoration: const InputDecoration(
                                  labelText: 'كود الترم (مثال: term_1)',
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.code),
                                ),
                                validator: (val) {
                                  if (val == null || val.trim().isEmpty) {
                                    return 'الرجاء إدخال كود الترم';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(height: 16),
                              // Term Name input
                              TextFormField(
                                controller: _termNameController,
                                decoration: const InputDecoration(
                                  labelText: 'اسم الترم (مثال: الترم الأول)',
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.calendar_today),
                                ),
                                validator: (val) {
                                  if (val == null || val.trim().isEmpty) {
                                    return 'الرجاء إدخال اسم الترم';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(height: 32),
                              ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.all(16),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                icon: const Icon(Icons.file_open),
                                label: const Text('اختيار ملف CSV والتحقق منه'),
                                onPressed: () => _pickAndParseFile(context),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildPreviewWidget(CsvImportPreviewReady state, BuildContext context) {
    final batch = state.batch;
    final theme = Theme.of(context);

    return Column(
      children: [
        // Summary Header Card
        Card(
          margin: const EdgeInsets.all(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'ملف: ${batch.fileName}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('الترم: ${batch.termName} (${batch.termId})'),
                const Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatCol('صالح للنشر', batch.validCount, const Color(0xFF10B981)),
                    _buildStatCol('غير صالح (أخطاء)', batch.invalidCount, const Color(0xFFF43F5E)),
                    _buildStatCol('الإجمالي', batch.rows.length, Colors.blue),
                  ],
                ),
              ],
            ),
          ),
        ),
        // Preview Table
        Expanded(
          child: ListView.builder(
            itemCount: batch.rows.length,
            itemBuilder: (context, index) {
              final row = batch.rows[index];
              return Card(
                color: row.isValid ? null : Colors.red.shade50,
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: row.isValid ? const Color(0xFFD1FAE5) : const Color(0xFFFFE4E6),
                    child: Text(
                      row.rowIndex.toString(),
                      style: TextStyle(
                        color: row.isValid ? const Color(0xFF064E3B) : const Color(0xFF4C0519),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  title: Text(row.studentName?.isNotEmpty == true ? row.studentName! : row.studentId),
                  subtitle: Text('كود المخدوم: ${row.studentId}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'الدرجة: ${row.score.toStringAsFixed(0)}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      if (!row.isValid)
                        Text(
                          row.validationError ?? 'خطأ في التحقق',
                          style: const TextStyle(color: Colors.red, fontSize: 11),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        // Bottom Action buttons
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    context.read<CsvImportBloc>().add(const ResetImport());
                  },
                  child: const Text('إلغاء وإعادة اختيار'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF10B981),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: batch.validCount > 0
                      ? () {
                          context.read<CsvImportBloc>().add(const PublishResults());
                        }
                      : null,
                  child: const Text('نشر الصفوف الصالحة'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSuccessWidget(CsvImportSuccess state, BuildContext context) {
    final result = state.result;
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(
            Icons.check_circle_outline,
            color: Color(0xFF10B981),
            size: 80,
          ),
          const SizedBox(height: 24),
          const Text(
            'اكتملت عملية الاستيراد!',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24),
          // Statistics Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildResultRow('تم نشرها بنجاح', result.successCount, const Color(0xFF10B981)),
                  const Divider(),
                  _buildResultRow('فشلت أو تم تخطيها', result.failureCount, const Color(0xFFF43F5E)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          if (result.errors.isNotEmpty) ...[
            const Text(
              'سجل الأخطاء والتحذيرات:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: ListView.builder(
                  itemCount: result.errors.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4.0),
                      child: Text(
                        result.errors[index],
                        style: const TextStyle(color: Colors.red, fontSize: 12),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
          ElevatedButton(
            onPressed: () {
              context.read<CsvImportBloc>().add(const ResetImport());
            },
            child: const Text('استيراد ملف آخر'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCol(String label, int val, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 4),
        Text(
          val.toString(),
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
        ),
      ],
    );
  }

  Widget _buildResultRow(String label, int count, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(
          count.toString(),
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color),
        ),
      ],
    );
  }
}

import 'package:church_management_system/core/constants/enums.dart';
import 'package:church_management_system/core/di/injection.dart';
import 'package:church_management_system/features/auth/data/models/auth_user.dart';
import 'package:church_management_system/features/results/domain/entities/result.dart';
import 'package:church_management_system/features/results/data/models/term_model.dart';
import 'package:church_management_system/features/results/presentation/bloc/results_bloc.dart';
import 'package:church_management_system/features/results/presentation/bloc/results_event.dart';
import 'package:church_management_system/features/results/presentation/bloc/results_state.dart';
import 'package:church_management_system/features/results/presentation/widgets/term_selector_widget.dart';
import 'package:church_management_system/features/student/domain/entities/student.dart';
import 'package:church_management_system/features/student/presentation/bloc/student_data/student_data_bloc.dart';
import 'package:church_management_system/features/team/domain/entities/team.dart';
import 'package:church_management_system/features/team/presentation/bloc/team_bloc.dart';
import 'package:church_management_system/features/team/data/repos/team_repository.dart';
import 'package:church_management_system/features/admin/data/admin_team_service.dart';
import 'package:church_management_system/shared/widgets/offline_indicator.dart';
import 'package:church_management_system/core/constants/routes.dart';
import 'package:church_management_system/core/routing/route_args.dart';
import 'package:church_management_system/features/results/presentation/widgets/export_results_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ResultsListScreen extends StatefulWidget {
  final AuthUser actor;

  const ResultsListScreen({super.key, required this.actor});

  @override
  State<ResultsListScreen> createState() => _ResultsListScreenState();
}

class _ResultsListScreenState extends State<ResultsListScreen> {
  late final StudentDataBloc _studentDataBloc;
  late final TeamBloc _teamCubit;
  String? _selectedTeamId;
  String? _selectedGroupId;
  String? _selectedTermId;

  @override
  void initState() {
    super.initState();
    _studentDataBloc = context.read<StudentDataBloc>();
    _teamCubit = TeamBloc(
      teamRepository: getIt<TeamRepository>(),
      adminTeamService: getIt<AdminTeamService>(),
    );

    _selectedTeamId = widget.actor.role == UserRole.servant &&
            widget.actor.effectiveAssignedTeamIds.length == 1
        ? widget.actor.effectiveAssignedTeamIds.first
        : null;

    _studentDataBloc.add(
      StudentsLoadRequested(
        actor: widget.actor,
        teamId: _selectedTeamId,
        includeArchived: false,
      ),
    );

    _loadTeams();
  }

  @override
  void dispose() {
    _teamCubit.close();
    super.dispose();
  }

  void _loadTeams() {
    if (widget.actor.role == UserRole.admin) {
      _teamCubit.add(const TeamLoadAllRequested());
    } else {
      final groupId = widget.actor.groupId;
      if (groupId != null && groupId.isNotEmpty) {
        _teamCubit.add(
          TeamLoadRequested(
            groupId,
            defaultTeamId: widget.actor.effectiveAssignedTeamIds.length == 1
                ? widget.actor.effectiveAssignedTeamIds.first
                : null,
          ),
        );
      }
    }
  }

  void _onTeamChanged(String? teamId, String? groupId) {
    setState(() {
      _selectedTeamId = teamId;
      _selectedGroupId = groupId;
    });

    _studentDataBloc.add(
      StudentsLoadRequested(
        actor: widget.actor,
        teamId: teamId,
        includeArchived: false,
      ),
    );

    if (groupId != null && groupId.isNotEmpty) {
      context.read<ResultsBloc>().add(ResultsLoadRequested(groupId: groupId));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return MultiBlocProvider(
      providers: [
        BlocProvider.value(value: _teamCubit),
        BlocProvider(
          create: (context) => ResultsBloc(resultsRepository: getIt()),
        ),
      ],
      child: Builder(
        builder: (context) {
          // Listen to team loading to trigger results load when first group is available
          return BlocListener<TeamBloc, TeamState>(
            listener: (context, teamState) {
              if (teamState is TeamLoaded && teamState.teams.isNotEmpty) {
                final defaultTeam = teamState.teams.first;
                _onTeamChanged(defaultTeam.id, defaultTeam.groupId);
              }
            },
            child: Scaffold(
              appBar: AppBar(
                title: const Text('كشف درجات المخدومين'),
                centerTitle: true,
                actions: [
                  BlocBuilder<StudentDataBloc, StudentDataState>(
                    builder: (context, studentState) {
                      final students = studentState is StudentDataLoaded
                          ? studentState.students.where((s) => !s.isArchived).toList()
                          : const <Student>[];
                      return BlocBuilder<ResultsBloc, ResultsState>(
                        builder: (context, resultsState) {
                          final results = resultsState is ResultsLoaded ? resultsState.results : const <Result>[];
                          return BlocBuilder<TeamBloc, TeamState>(
                            builder: (context, teamState) {
                              final teams = teamState is TeamLoaded ? teamState.teams : const <Team>[];
                              final currentTeam = teams.firstWhere(
                                (t) => t.id == _selectedTeamId,
                                orElse: () => const Team(id: '', name: 'عام', groupId: ''),
                              );
                              return ExportResultsButton(
                                results: results,
                                students: students,
                                teamName: currentTeam.name,
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                  if (widget.actor.role == UserRole.admin)
                    IconButton(
                      icon: const Icon(Icons.upload_file_outlined),
                      tooltip: 'استيراد CSV',
                      onPressed: () {
                        Navigator.pushNamed(
                          context,
                          csvImport,
                          arguments: CsvImportArgs(actor: widget.actor),
                        );
                      },
                    ),
                ],
              ),
              body: Column(
                children: [
                  const OfflineIndicator(),
                  // Top Filters Section
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        // Team Dropdown Selector
                        BlocBuilder<TeamBloc, TeamState>(
                          builder: (context, teamState) {
                            if (teamState is TeamLoading) {
                              return const Center(child: CircularProgressIndicator());
                            }
                            if (teamState is TeamLoaded) {
                              final teams = teamState.teams;
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
                                decoration: BoxDecoration(
                                  color: theme.cardColor,
                                  borderRadius: BorderRadius.circular(12.0),
                                  border: Border.all(color: theme.dividerColor),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String?>(
                                    value: _selectedTeamId,
                                    hint: const Text('اختر الفريق'),
                                    isExpanded: true,
                                    onChanged: (val) {
                                      final selectedTeam = teams.firstWhere((t) => t.id == val);
                                      _onTeamChanged(val, selectedTeam.groupId);
                                    },
                                    items: teams.map((team) {
                                      return DropdownMenuItem<String?>(
                                        value: team.id,
                                        child: Text(team.name),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              );
                            }
                            return const SizedBox.shrink();
                          },
                        ),
                        const SizedBox(height: 12.0),
                        // Term Selector
                        BlocBuilder<ResultsBloc, ResultsState>(
                          builder: (context, resultsState) {
                            final List<TermModel> terms = resultsState is ResultsLoaded ? resultsState.terms : const <TermModel>[];
                            return TermSelectorWidget(
                              terms: terms,
                              selectedTermId: _selectedTermId,
                              onChanged: (termId) {
                                setState(() {
                                  _selectedTermId = termId;
                                });
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  // Students & Results List
                  Expanded(
                    child: BlocBuilder<StudentDataBloc, StudentDataState>(
                      builder: (context, studentState) {
                        if (studentState is StudentDataLoading) {
                          return const Center(child: CircularProgressIndicator());
                        }

                        final students = studentState is StudentDataLoaded
                            ? studentState.students.where((s) => !s.isArchived).toList()
                            : const <Student>[];

                        if (students.isEmpty) {
                          return Center(
                            child: Text(
                              'لا يوجد مخدومين في هذا الفريق',
                              style: theme.textTheme.titleMedium?.copyWith(
                                color: theme.hintColor,
                              ),
                            ),
                          );
                        }

                        return BlocBuilder<ResultsBloc, ResultsState>(
                          builder: (context, resultsState) {
                            if (resultsState is ResultsLoading) {
                              return const Center(child: CircularProgressIndicator());
                            }

                            final resultsMap = <String, double>{};
                            if (resultsState is ResultsLoaded) {
                              for (final res in resultsState.results) {
                                if (_selectedTermId == null || res.termId == _selectedTermId) {
                                  resultsMap[res.studentId] = res.score;
                                }
                              }
                            }

                            return ListView.builder(
                              itemCount: students.length,
                              itemBuilder: (context, index) {
                                final student = students[index];
                                final score = resultsMap[student.docID];

                                return Card(
                                  margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6.0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: ListTile(
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                    title: Text(
                                      student.name,
                                      style: const TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                    subtitle: Text('الصف: ${student.grade}'),
                                    trailing: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
                                      decoration: BoxDecoration(
                                        color: score != null
                                            ? (score >= 70
                                                ? const Color(0xFF10B981).withOpacity(0.1)
                                                : (score >= 50
                                                    ? Colors.amber.withOpacity(0.1)
                                                    : const Color(0xFFF43F5E).withOpacity(0.1)))
                                            : Colors.grey.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(20.0),
                                      ),
                                      child: Text(
                                        score != null ? score.toStringAsFixed(0) : 'غير مرصود',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: score != null
                                              ? (score >= 70
                                                  ? const Color(0xFF10B981)
                                                  : (score >= 50 ? Colors.amber : const Color(0xFFF43F5E)))
                                              : theme.hintColor,
                                        ),
                                      ),
                                    ),
                                    onTap: () {
                                      Navigator.pushNamed(
                                        context,
                                        resultsHistory,
                                        arguments: ResultsHistoryArgs(
                                          actor: widget.actor,
                                          studentId: student.docID,
                                          studentName: student.name,
                                        ),
                                      );
                                    },
                                  ),
                                );
                              },
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

import 'package:church_management_system/features/results/data/models/term_model.dart';
import 'package:flutter/material.dart';

class TermSelectorWidget extends StatelessWidget {
  final List<TermModel> terms;
  final String? selectedTermId;
  final ValueChanged<String?> onChanged;

  const TermSelectorWidget({
    super.key,
    required this.terms,
    required this.selectedTermId,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12.0),
        border: Border.all(
          color: theme.dividerColor,
          width: 1.0,
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String?>(
          value: selectedTermId,
          hint: const Text('اختر الترم (الكل)'),
          isExpanded: true,
          icon: const Icon(Icons.arrow_drop_down_circle_outlined),
          onChanged: onChanged,
          items: [
            const DropdownMenuItem<String?>(
              value: null,
              child: Text('جميع الأترام'),
            ),
            ...terms.map((term) {
              return DropdownMenuItem<String?>(
                value: term.id,
                child: Text(term.name),
              );
            }),
          ],
        ),
      ),
    );
  }
}

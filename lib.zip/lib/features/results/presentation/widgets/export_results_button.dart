import 'dart:io';
import 'package:church_management_system/core/utils/data_export_service.dart';
import 'package:church_management_system/features/results/domain/entities/result.dart';
import 'package:church_management_system/features/student/domain/entities/student.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ExportResultsButton extends StatelessWidget {
  final List<Result> results;
  final List<Student> students;
  final String teamName;

  const ExportResultsButton({
    super.key,
    required this.results,
    required this.students,
    required this.teamName,
  });

  Future<void> _exportResults(BuildContext context) async {
    if (results.isEmpty) return;

    try {
      final Map<String, String> studentNames = {
        for (final s in students) s.docID: s.name,
      };

      final exportService = DataExportService();
      final csvString = exportService.generateResultsCsv(results, studentNames);

      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/درجات_${teamName}.csv');
      await file.writeAsString(csvString);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'درجات مخدومين فريق $teamName',
      );

      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('فشل تصدير الدرجات: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.download),
      tooltip: 'تصدير كشف الدرجات',
      onPressed: results.isEmpty ? null : () => _exportResults(context),
    );
  }
}

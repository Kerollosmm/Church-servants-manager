import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:church_management_system/core/constants/enums.dart';
import 'package:church_management_system/core/constants/firestore_collections.dart';
import 'package:church_management_system/features/admin/data/admin_team_membership_service.dart';
import 'package:church_management_system/features/auth/data/models/auth_user.dart';
import 'package:church_management_system/features/servant/data/models/servant_models.dart';
import 'package:church_management_system/features/student/data/models/student_model.dart';
import 'package:church_management_system/features/team/data/models/team_model.dart';

/// Admin-only operations that touch multiple collections.
///
/// Feature: Teams
/// - Admin assigns a servant responsible for a team.
/// - Admin assigns/removes students to/from a team.
///
/// NOTE: Permissions must be enforced by Firestore Security Rules.
class AdminTeamService {
  final FirebaseFirestore _firestore;
  final AdminTeamMembershipService _membershipService;

  AdminTeamService({
    FirebaseFirestore? firestore,
    AdminTeamMembershipService? membershipService,
  }) : _firestore = firestore ?? FirebaseFirestore.instance,
       _membershipService =
           membershipService ??
           AdminTeamMembershipService(firestore: firestore);

  CollectionReference<Map<String, dynamic>> get _classes =>
      _firestore.collection(FirestoreCollections.classes);
  CollectionReference<Map<String, dynamic>> get _users =>
      _firestore.collection(FirestoreCollections.users);
  DocumentReference<Map<String, dynamic>> _teamRef(String teamId) =>
      _classes.doc(teamId);

  DocumentReference<Map<String, dynamic>> _userRef(String userId) =>
      _users.doc(userId);

  /// Safe Firestore field reader — avoids _AssertionError from `as String?`
  /// casts when Firestore stores the value as a non-String type.
  String? _readString(Map<String, dynamic> data, String key) {
    final value = data[key];
    if (value == null) return null;
    if (value is String) return value;
    return value.toString();
  }

  void _assertAdmin(AuthUser actor) {
    if (actor.role != UserRole.admin) {
      throw StateError('Permission denied: admin only');
    }
  }

  void _validateServantForTeam({
    required TeamModel team,
    required String servantDocId,
    required Map<String, dynamic> servantData,
  }) {
    if (team.isArchived) {
      throw StateError('Cannot assign a servant to an archived team');
    }

    // Use safe _readString to avoid _AssertionError / TypeError when the
    // Firestore field is stored as a non-String type (e.g. null, int).
    final role = _readString(servantData, 'role')?.trim().toLowerCase();
    if (role != UserRole.servant.name) {
      throw StateError('Selected user is not a servant');
    }

    final isArchived = servantData['isArchived'] == true;
    if (isArchived) {
      throw StateError('Selected servant is archived');
    }

    final groupId = _readString(servantData, 'groupId')?.trim();
    if (groupId == null || groupId.isEmpty) {
      throw StateError(
        'Selected servant ($servantDocId) is missing group assignment',
      );
    }
    if (groupId != team.groupId) {
      throw StateError(
        'Cannot assign servant from group "$groupId" to team group "${team.groupId}"',
      );
    }
  }

  List<String> _extractAssignedTeamIds(Map<String, dynamic> data) {
    final ids = <String>[];

    final assignedTeamIds = data['assignedTeamIds'];
    if (assignedTeamIds is Iterable) {
      for (final value in assignedTeamIds) {
        if (value is! String) continue;
        final id = value.trim();
        if (id.isEmpty || ids.contains(id)) continue;
        ids.add(id);
      }
    }

    final assignedTeamId = data['assignedTeamId'];
    if (assignedTeamId is String) {
      final id = assignedTeamId.trim();
      if (id.isNotEmpty && !ids.contains(id)) {
        ids.add(id);
      }
    }

    return ids;
  }

  void _removeTeamFromServant(
    Transaction transaction,
    DocumentReference<Map<String, dynamic>> servantRef,
    Map<String, dynamic> servantData,
    String teamId,
  ) {
    final teamIds = _extractAssignedTeamIds(
      servantData,
    )..removeWhere((id) => id == teamId);
    transaction.set(
      servantRef,
      _servantAssignmentPatch(teamIds),
      SetOptions(merge: true),
    );
  }

  Map<String, dynamic> _servantAssignmentPatch(List<String> teamIds) {
    if (teamIds.isEmpty) {
      return {
        'assignedTeamIds': FieldValue.delete(),
        'assignedTeamId': FieldValue.delete(),
        'updatedAt': FieldValue.serverTimestamp(),
      };
    }
    return {
      'assignedTeamIds': teamIds,
      // Keep legacy field for backward compatibility.
      'assignedTeamId': teamIds.first,
      'updatedAt': FieldValue.serverTimestamp(),
    };
  }

  /// Assign [servant] as the responsible servant for [team].
  ///
  /// Updates:
  /// - Classes/{teamId}: assignedServantId + assignedServantName
  /// - Users/{servantDocId}: assignedTeamIds (+ legacy assignedTeamId)
  /// - If the team had a previous servant, removes this team from their list.
  Future<void> assignServantToTeam({
    required AuthUser actor,
    required TeamModel team,
    required ServantModel servant,
  }) async {
    _assertAdmin(actor);

    final teamRef = _teamRef(team.id);
    final newServantRef = _userRef(servant.docID);

    await _firestore.runTransaction((transaction) async {
      final teamSnap = await transaction.get(teamRef);
      if (!teamSnap.exists) {
        throw StateError('Team not found');
      }

      final teamData = teamSnap.data() ?? <String, dynamic>{};
      final oldServantId = _readString(teamData, 'assignedServantId')?.trim();
      final oldServantRef = oldServantId == null || oldServantId.isEmpty
          ? null
          : _userRef(oldServantId);
      final shouldRemoveOldServant =
          oldServantRef != null && oldServantId != servant.docID;

      final newServantSnap = await transaction.get(newServantRef);
      final newServantData = newServantSnap.data();
      if (!newServantSnap.exists || newServantData == null) {
        throw StateError('Servant not found');
      }

      Map<String, dynamic>? oldServantData;
      if (shouldRemoveOldServant) {
        final oldServantSnap = await transaction.get(oldServantRef);
        if (oldServantSnap.exists) {
          oldServantData = oldServantSnap.data() ?? <String, dynamic>{};
        }
      }

      _validateServantForTeam(
        team: team,
        servantDocId: servant.docID,
        servantData: newServantData,
      );

      final newServantTeamIds = _extractAssignedTeamIds(newServantData);
      if (!newServantTeamIds.contains(team.id)) {
        newServantTeamIds.add(team.id);
      }

      transaction.update(teamRef, {
        'assignedServantId': servant.docID,
        'assignedServantName': _readString(newServantData, 'name') ?? servant.name,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (shouldRemoveOldServant && oldServantData != null) {
        _removeTeamFromServant(
          transaction,
          oldServantRef,
          oldServantData,
          team.id,
        );
      }

      transaction.set(newServantRef, {
        ..._servantAssignmentPatch(newServantTeamIds),
        'groupId': team.groupId,
      }, SetOptions(merge: true));
    });
  }

  /// Remove any responsible servant from [team] and removes this team from that servant's assignment list.
  Future<void> unassignServantFromTeam({
    required AuthUser actor,
    required TeamModel team,
  }) async {
    _assertAdmin(actor);

    final teamRef = _teamRef(team.id);

    await _firestore.runTransaction((transaction) async {
      final teamSnap = await transaction.get(teamRef);
      if (!teamSnap.exists) {
        throw StateError('Team not found');
      }

      final data = teamSnap.data() ?? <String, dynamic>{};
      final oldServantId = _readString(data, 'assignedServantId')?.trim();
      final oldServantRef = oldServantId == null || oldServantId.isEmpty
          ? null
          : _userRef(oldServantId);
      Map<String, dynamic>? oldServantData;

      if (oldServantRef != null) {
        final oldServantSnap = await transaction.get(oldServantRef);
        if (oldServantSnap.exists) {
          oldServantData = oldServantSnap.data() ?? <String, dynamic>{};
        }
      }

      transaction.update(teamRef, {
        'assignedServantId': FieldValue.delete(),
        'assignedServantName': FieldValue.delete(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (oldServantRef != null && oldServantData != null) {
        _removeTeamFromServant(transaction, oldServantRef, oldServantData, team.id);
      }
    });
  }

  /// Set the exact list of students that belong to [team].
  ///
  /// - Students selected => classId = team.id, team_name = team.name
  /// - Students removed  => classId deleted, team_name cleared
  ///
  /// Also maintains Classes/{teamId}.student_ids array (best-effort).
  Future<void> setStudentsForTeam({
    required AuthUser actor,
    required TeamModel team,
    required List<StudentModel> selectedStudents,
  }) async {
    if (team.isArchived) {
      throw StateError('Cannot manage members for an archived team');
    }

    await _membershipService.setStudentsForTeam(
      actor: actor,
      team: team,
      selectedStudents: selectedStudents,
    );
  }
}

import 'package:church_management_system/features/attendance/data/models/attendance_session.dart';
import 'package:church_management_system/features/results/domain/entities/csv_import_models.dart'; // We can define WeeklyAttendanceStat here or in a separate file
import 'package:hive/hive.dart';

class WeeklyAttendanceStat {
  final DateTime weekStart;
  final String weekLabel;
  final int totalRoster;
  final int totalPresent;
  final int totalLate;
  final double attendanceRate;
  final int sessionCount;

  const WeeklyAttendanceStat({
    required this.weekStart,
    required this.weekLabel,
    required this.totalRoster,
    required this.totalPresent,
    required this.totalLate,
    required this.attendanceRate,
    required this.sessionCount,
  });
}

class AttendanceTrendsService {
  Future<List<WeeklyAttendanceStat>> getWeeklyTrends({int weeks = 8}) async {
    final Box<AttendanceSessionModel> box = await Hive.openBox<AttendanceSessionModel>(
      'attendance_sessions_cache_box',
    );

    final sessions = box.values.map((m) => m.toDomain()).toList();
    if (sessions.isEmpty) return const [];

    // Group sessions by week start (Monday)
    final Map<DateTime, List<AttendanceSession>> grouped = {};
    for (final session in sessions) {
      if (!session.isClosed) continue; // Only count closed (completed) sessions for trends
      
      final date = session.startsAt;
      final weekStart = DateTime.utc(date.year, date.month, date.day)
          .subtract(Duration(days: date.weekday - 1));
      
      grouped.putIfAbsent(weekStart, () => []).add(session);
    }

    final List<WeeklyAttendanceStat> stats = [];
    final sortedWeeks = grouped.keys.toList()..sort();

    for (final weekStart in sortedWeeks) {
      final weekSessions = grouped[weekStart]!;
      int totalPresent = 0;
      int totalLate = 0;
      int totalAbsent = 0;

      for (final s in weekSessions) {
        totalPresent += s.presentCount;
        totalLate += s.lateCount;
        totalAbsent += s.absentCount;
      }

      final totalRoster = totalPresent + totalLate + totalAbsent;
      final attendanceRate = totalRoster > 0
          ? ((totalPresent + totalLate) / totalRoster) * 100
          : 0.0;

      // Label as "الأسبوع (DD/MM)"
      final label = '${weekStart.day}/${weekStart.month}';

      stats.add(WeeklyAttendanceStat(
        weekStart: weekStart,
        weekLabel: label,
        totalRoster: totalRoster,
        totalPresent: totalPresent,
        totalLate: totalLate,
        attendanceRate: attendanceRate,
        sessionCount: weekSessions.length,
      ));
    }

    // Return the last N weeks
    if (stats.length > weeks) {
      return stats.sublist(stats.length - weeks);
    }
    return stats;
  }
}

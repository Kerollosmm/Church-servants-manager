import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'add_student_bloc.dart';

class AddStudentScreen extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController gradeController = TextEditingController();
  final TextEditingController classController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Student')),
      body: BlocProvider(
        create: (context) => AddStudentBloc(),
        child: BlocBuilder<AddStudentBloc, AddStudentState>(
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(labelText: 'Name'),
                  ),
                  TextField(
                    controller: phoneController,
                    decoration: InputDecoration(labelText: 'Phone'),
                  ),
                  TextField(
                    controller: gradeController,
                    decoration: InputDecoration(labelText: 'Grade'),
                  ),
                  TextField(
                    controller: classController,
                    decoration: InputDecoration(labelText: 'Class'),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      context.read<AddStudentBloc>().add(
                        AddStudentEvent(
                          name: nameController.text,
                          phone: phoneController.text,
                          grade: gradeController.text,
                          className: classController.text,
                        ),
                      );
                    },
                    child: Text('Add Student'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

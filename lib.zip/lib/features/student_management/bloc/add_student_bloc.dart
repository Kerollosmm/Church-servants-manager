import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddStudentEvent {
  final String name;
  final String phone;
  final String grade;
  final String className;

  AddStudentEvent({
    required this.name,
    required this.phone,
    required this.grade,
    required this.className,
  });
}

class AddStudentState {
  final bool isLoading;
  final bool isSuccess;
  final String? error;

  AddStudentState() : isLoading = false, isSuccess = false, error = null;
  AddStudentState.loading() : isLoading = true, isSuccess = false, error = null;
  AddStudentState.success() : isLoading = false, isSuccess = true, error = null;
  AddStudentState.error(this.error) : isLoading = false, isSuccess = false;
}

class AddStudentBloc extends Bloc<AddStudentEvent, AddStudentState> {
  final FirebaseFirestore _firestore;

  AddStudentBloc() : _firestore = FirebaseFirestore.instance, super(AddStudentState()) {
    on<AddStudentEvent>(_handleAddStudent);
  }

  Future<void> _handleAddStudent(AddStudentEvent event, Emitter<AddStudentState> emit) async {
    emit(AddStudentState.loading());

    try {
      // Direct Firestore write without local storage
      await _firestore.collection('students').add({
        'name': event.name,
        'phone': event.phone,
        'grade': event.grade,
        'class': event.className,
        'createdAt': FieldValue.serverTimestamp(),
      });

      emit(AddStudentState.success());
    } catch (e) {
      emit(AddStudentState.error(e.toString()));
    }
  }
}

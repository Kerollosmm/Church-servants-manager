import 'package:church_managment_system/core/routing/route_args.dart';
import 'package:church_managment_system/core/constants/firestore_collections.dart';
import 'package:church_managment_system/core/theme/app_colors.dart';
import 'package:church_managment_system/core/theme/app_spacing.dart';
import 'package:church_managment_system/features/student/data/models/student_model.dart';
import 'package:church_managment_system/features/student/data/repos/student_data_repository.dart';
import 'package:church_managment_system/features/team/presentation/bloc/team_cubit.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// Admin-only screen: pick which students belong to a specific team.
///
/// The screen shows all students in the same group/year as the team.
/// Checked students will be assigned to the team on Save.
class TeamMembersScreen extends StatefulWidget {
  final TeamMembersArgs args;

  const TeamMembersScreen({super.key, required this.args});

  @override
  State<TeamMembersScreen> createState() => _TeamMembersScreenState();
}

class _TeamMembersScreenState extends State<TeamMembersScreen> {
  final _searchController = TextEditingController();
  final Map<String, bool> _selected = {};

  List<StudentModel> _all = [];
  bool _loading = true;
  bool _saving = false;
  String? _loadError;
  bool _loadedFromCache = false;

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<_StudentsLoadResult> _loadStudentsForGroupWithFallback(
    String groupId,
  ) async {
    final studentsCollection = FirebaseFirestore.instance.collection(
      FirestoreCollections.students,
    );
    final studentRepo = context.read<StudentDataRepository>();

    List<StudentModel> mapDocs(QuerySnapshot<Map<String, dynamic>> snapshot) {
      return snapshot.docs
          .map((doc) => StudentModel.fromMap(doc.data(), doc.id))
          .toList(growable: false);
    }

    try {
      final serverSnapshot = await studentsCollection
          .where('group', isEqualTo: groupId)
          .get(const GetOptions(source: Source.server));
      return _StudentsLoadResult(students: mapDocs(serverSnapshot));
    } catch (_) {
      try {
        final cacheSnapshot = await studentsCollection
            .where('group', isEqualTo: groupId)
            .get(const GetOptions(source: Source.cache));
        return _StudentsLoadResult(
          students: mapDocs(cacheSnapshot),
          isFromCache: true,
        );
      } catch (_) {
        final students = await studentRepo.getStudentsByGroup(groupId);
        return _StudentsLoadResult(students: students, isFromCache: true);
      }
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadError = null;
    });
    try {
      final team = widget.args.team;
      final result = await _loadStudentsForGroupWithFallback(team.groupId);
      final students = result.students;
      students.sort((a, b) => a.name.compareTo(b.name));

      _all = students;
      _loadedFromCache = result.isFromCache;
      _selected.clear();
      for (final s in students) {
        _selected[s.docID] = (s.classId == team.id);
      }
    } catch (e) {
      _all = [];
      _loadedFromCache = false;
      _loadError = 'Failed to load students: $e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<StudentModel> get _filtered {
    final q = _searchController.text.trim().toLowerCase();
    if (q.isEmpty) return _all;
    return _all.where((s) => s.name.toLowerCase().contains(q)).toList();
  }

  Future<void> _save() async {
    final team = widget.args.team;
    final actor = widget.args.actor;

    final selectedStudents = _all
        .where((s) => (_selected[s.docID] ?? false) == true)
        .toList();

    setState(() => _saving = true);
    context.read<TeamCubit>().setTeamMembers(
      actor: actor,
      team: team,
      students: selectedStudents,
    );
  }

  @override
  Widget build(BuildContext context) {
    final team = widget.args.team;
    final selectedCount = _selected.values.where((v) => v == true).length;

    return BlocListener<TeamCubit, TeamState>(
      listener: (context, state) {
        if (state is TeamError) {
          setState(() => _saving = false);
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.message)));
        }
        if (state is TeamOperationSuccess) {
          setState(() => _saving = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: AppColors.secondary,
            ),
          );
          Navigator.of(context).pop(true);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('Members • ${team.name}'),
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.white,
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
              child: Center(
                child: Text(
                  '$selectedCount',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            TextButton.icon(
              onPressed: (_loading || _saving) ? null : _save,
              icon: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: const Text('Save'),
              style: TextButton.styleFrom(foregroundColor: AppColors.white),
            ),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _loadError != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.lg),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.error_outline,
                        size: 48,
                        color: AppColors.error,
                      ),
                      AppSpacing.gapMd,
                      Text(_loadError!, textAlign: TextAlign.center),
                      AppSpacing.gapMd,
                      FilledButton.icon(
                        onPressed: _load,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Retry'),
                      ),
                    ],
                  ),
                ),
              )
            : Column(
                children: [
                  if (_loadedFromCache)
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.fromLTRB(
                        AppSpacing.md,
                        AppSpacing.md,
                        AppSpacing.md,
                        0,
                      ),
                      padding: const EdgeInsets.all(AppSpacing.sm),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceContainer,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        'Offline mode: showing cached students.',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    child: TextField(
                      controller: _searchController,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: 'Search students...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      itemCount: _filtered.length,
                      separatorBuilder: (_, index) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final s = _filtered[index];
                        final isChecked = _selected[s.docID] ?? false;

                        return CheckboxListTile(
                          value: isChecked,
                          onChanged: _saving
                              ? null
                              : (val) {
                                  setState(() {
                                    _selected[s.docID] = val ?? false;
                                  });
                                },
                          title: Text(s.name),
                          subtitle: Text('Grade ${s.grade}'),
                          controlAffinity: ListTileControlAffinity.leading,
                        );
                      },
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _StudentsLoadResult {
  final List<StudentModel> students;
  final bool isFromCache;

  const _StudentsLoadResult({required this.students, this.isFromCache = false});
}

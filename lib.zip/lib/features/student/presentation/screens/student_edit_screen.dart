import 'package:church_managment_system/core/constants/enums.dart';
import 'package:church_managment_system/core/routing/route_args.dart';
import 'package:church_managment_system/core/theme/app_colors.dart';
import 'package:church_managment_system/core/theme/app_spacing.dart';
import 'package:church_managment_system/core/utils/validators.dart';
import 'package:church_managment_system/features/student/data/models/student_model.dart';
import 'package:church_managment_system/features/student/presentation/bloc/student_data/student_data_bloc.dart';
import 'package:church_managment_system/features/team/presentation/widgets/team_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uuid/uuid.dart';

class StudentEditScreen extends StatefulWidget {
  final StudentEditArgs args;

  const StudentEditScreen({super.key, required this.args});

  @override
  State<StudentEditScreen> createState() => _StudentEditScreenState();
}

class _StudentEditScreenState extends State<StudentEditScreen> {
  final _formKey = GlobalKey<FormState>();
  final _uuid = const Uuid();

  late final TextEditingController _name;
  late final TextEditingController _mobile;
  late final TextEditingController _motherPhone;
  late final TextEditingController _fatherPhone;
  late final TextEditingController _school;
  late final TextEditingController _address;
  late final TextEditingController _fatherOfConfession;
  late final TextEditingController _notes;
  late final TextEditingController _imageUrl;

  late Group _group;
  late EducationStage _educationStage;
  late int _grade;
  DateTime? _birthdate;
  String? _selectedClassId;

  @override
  void initState() {
    super.initState();
    final student = widget.args.student;

    _name = TextEditingController(text: student?.name ?? '');
    _mobile = TextEditingController(text: student?.mobile ?? '');
    _motherPhone = TextEditingController(text: student?.motherPhone ?? '');
    _fatherPhone = TextEditingController(text: student?.fatherPhone ?? '');
    _school = TextEditingController(text: student?.school ?? '');
    _address = TextEditingController(text: student?.address ?? '');
    _fatherOfConfession = TextEditingController(
      text: student?.fatherOfConfession ?? '',
    );
    _notes = TextEditingController(text: student?.notes ?? '');
    _imageUrl = TextEditingController(text: student?.imageUrl ?? '');

    final actor = widget.args.actor;

    if (actor.role == UserRole.servant && actor.groupId != null) {
      _group = Group.values.firstWhere(
        (g) => g.name == actor.groupId,
        orElse: () => Group.year1,
      );
    } else {
      _group = student?.group ?? Group.year1;
    }

    _educationStage = student?.educationStage ?? EducationStage.preparatory;
    _grade = student?.grade ?? 1;
    _birthdate = student?.birthdate;
    _selectedClassId = student?.classId;
  }

  @override
  void dispose() {
    _name.dispose();
    _mobile.dispose();
    _motherPhone.dispose();
    _fatherPhone.dispose();
    _school.dispose();
    _address.dispose();
    _fatherOfConfession.dispose();
    _notes.dispose();
    _imageUrl.dispose();
    super.dispose();
  }

  String _classIdForGroup(Group group) => group.name; // year1/year2/year3

  Future<void> _pickBirthdate() async {
    final now = DateTime.now();
    final initial = _birthdate ?? DateTime(now.year - 14, now.month, now.day);
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2012),
      lastDate: now,
      initialDate: initial,
    );
    if (selected != null) {
      setState(() => _birthdate = selected);
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final actor = widget.args.actor;
    final isEditing = widget.args.isEditing;
    final existing = widget.args.student;

    final uid = existing?.uid ?? _uuid.v4();
    final docId = existing?.docID ?? 'temp';

    final classId = _selectedClassId ?? _classIdForGroup(_group);

    final student = StudentModel(
      uid: uid,
      docID: docId,
      name: _name.text.trim(),
      imageUrl: _imageUrl.text.trim().isEmpty ? null : _imageUrl.text.trim(),
      role: UserRole.student,
      mobile: _mobile.text.trim(),
      group: _group,
      teamName: '',
      motherPhone: _motherPhone.text.trim(),
      fatherPhone: _fatherPhone.text.trim(),
      grade: _grade,
      educationStage: _educationStage,
      school: _school.text.trim().isEmpty ? null : _school.text.trim(),
      address: _address.text.trim().isEmpty ? null : _address.text.trim(),
      birthdate: _birthdate,
      fatherOfConfession: _fatherOfConfession.text.trim(),
      notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      classId: classId,
    );

    final bloc = context.read<StudentDataBloc>();
    if (isEditing) {
      bloc.add(StudentUpdated(actor: actor, student: student));
    } else {
      bloc.add(StudentCreated(actor: actor, student: student));
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final actor = widget.args.actor;
    final isTeacher = actor.role == UserRole.servant;
    final isEditing = widget.args.isEditing;

    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(isEditing ? 'Edit Student' : 'Add Student')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(AppSpacing.md),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Student Info',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: AppColors.primary,
                        ),
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _name,
                        decoration: const InputDecoration(
                          labelText: 'Full Name',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                        validator: Validators.validateName,
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _mobile,
                        decoration: const InputDecoration(
                          labelText: 'Mobile',
                          prefixIcon: Icon(Icons.phone_outlined),
                        ),
                        validator: Validators.validatePhone,
                      ),
                      AppSpacing.gapMd,
                      // Team assignment dropdown
                      TeamDropdown(
                        groupId: _group.name,
                        defaultTeamId: _selectedClassId,
                        showAllOption: false,
                        restrictToTeamId: isTeacher
                            ? actor.assignedTeamId
                            : null,
                        label: 'Assign to Team',
                        onChanged: (teamId) {
                          setState(() => _selectedClassId = teamId);
                        },
                      ),
                      AppSpacing.gapMd,
                      DropdownMenu<Group>(
                        initialSelection: _group,
                        enabled: !isTeacher,
                        dropdownMenuEntries: Group.values
                            .map(
                              (g) => DropdownMenuEntry(value: g, label: g.name),
                            )
                            .toList(),
                        onSelected: (g) {
                          if (g == null) return;
                          setState(() {
                            _group = g;
                            _selectedClassId = null;
                          });
                        },
                        label: Text(isTeacher ? 'Group (Assigned)' : 'Group'),
                        leadingIcon: const Icon(Icons.school_outlined),
                      ),
                      AppSpacing.gapMd,
                      DropdownMenu<EducationStage>(
                        initialSelection: _educationStage,
                        dropdownMenuEntries: EducationStage.values
                            .map(
                              (s) => DropdownMenuEntry(value: s, label: s.name),
                            )
                            .toList(),
                        onSelected: (s) {
                          if (s == null) return;
                          setState(() => _educationStage = s);
                        },
                        label: const Text('Education Stage'),
                        leadingIcon: const Icon(Icons.badge_outlined),
                      ),
                      AppSpacing.gapMd,
                      DropdownMenu<int>(
                        initialSelection: _grade,
                        dropdownMenuEntries: List.generate(
                          12,
                          (i) => DropdownMenuEntry(
                            value: i + 1,
                            label: 'Grade ${i + 1}',
                          ),
                        ),
                        onSelected: (g) {
                          if (g == null) return;
                          setState(() => _grade = g);
                        },
                        label: const Text('Grade'),
                        leadingIcon: const Icon(Icons.numbers_outlined),
                      ),
                    ],
                  ),
                ),
              ),
              AppSpacing.gapMd,
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Family Contacts',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: AppColors.primary,
                        ),
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _motherPhone,
                        decoration: const InputDecoration(
                          labelText: 'Mother Phone',
                          prefixIcon: Icon(Icons.phone_outlined),
                        ),
                        validator: Validators.validatePhone,
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _fatherPhone,
                        decoration: const InputDecoration(
                          labelText: 'Father Phone',
                          prefixIcon: Icon(Icons.phone_outlined),
                        ),
                        validator: Validators.validatePhone,
                      ),
                    ],
                  ),
                ),
              ),
              AppSpacing.gapMd,
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Other Details',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: AppColors.primary,
                        ),
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _fatherOfConfession,
                        decoration: const InputDecoration(
                          labelText: 'Father of Confession',
                          prefixIcon: Icon(Icons.church_outlined),
                        ),
                        validator: Validators.validateName,
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _school,
                        decoration: const InputDecoration(
                          labelText: 'School / College (optional)',
                          prefixIcon: Icon(Icons.school_outlined),
                        ),
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _address,
                        decoration: const InputDecoration(
                          labelText: 'Address (optional)',
                          prefixIcon: Icon(Icons.location_on_outlined),
                        ),
                      ),
                      AppSpacing.gapMd,
                      Row(
                        children: [
                          Expanded(
                            child: InputDecorator(
                              decoration: const InputDecoration(
                                labelText: 'Birthdate (optional)',
                                prefixIcon: Icon(Icons.cake_outlined),
                              ),
                              child: Text(
                                _birthdate == null
                                    ? '—'
                                    : '${_birthdate!.year}-${_birthdate!.month.toString().padLeft(2, '0')}-${_birthdate!.day.toString().padLeft(2, '0')}',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                          ),
                          AppSpacing.gapSm,
                          FilledButton(
                            onPressed: _pickBirthdate,
                            child: const Text('Pick'),
                          ),
                        ],
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _notes,
                        decoration: const InputDecoration(
                          labelText: 'Notes (optional)',
                          prefixIcon: Icon(Icons.notes_outlined),
                        ),
                        maxLines: 2,
                      ),
                      AppSpacing.gapMd,
                      TextFormField(
                        controller: _imageUrl,
                        decoration: const InputDecoration(
                          labelText: 'Image URL (optional)',
                          prefixIcon: Icon(Icons.image_outlined),
                        ),
                      ),
                      AppSpacing.gapMd,
                      Container(
                        padding: const EdgeInsets.all(AppSpacing.md),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceContainer,
                          borderRadius: AppRadius.mdRadius,
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.lock_outline, color: AppColors.primary),
                            AppSpacing.gapSm,
                            Expanded(
                              child: Text(
                                isTeacher
                                    ? 'Teacher scope enforced: ${actor.groupId ?? 'not assigned'}'
                                    : 'Admin access: full CRUD',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              AppSpacing.gapMd,
              FilledButton.icon(
                key: const Key('submit_student_button'),
                onPressed: _submit,
                icon: Icon(isEditing ? Icons.save_outlined : Icons.add),
                label: Text(isEditing ? 'Save Changes' : 'Create Student'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

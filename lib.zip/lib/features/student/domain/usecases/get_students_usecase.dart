import 'package:church_management_system/features/auth/data/models/auth_user.dart';
import 'package:church_management_system/features/student/data/models/student_model.dart';
import 'package:church_management_system/features/student/data/repos/student_data_repository.dart';
import 'package:church_management_system/features/student/domain/usecases/get_students_stream_usecase.dart';

// FIX [P1]: extracted student loading/lookups behind a use case.
class GetStudentsUseCase {
  const GetStudentsUseCase(this._repository, this._getStudentsStreamUseCase);

  final StudentDataRepository _repository;
  final GetStudentsStreamUseCase _getStudentsStreamUseCase;

  Stream<List<StudentModel>>? watch({
    required AuthUser actor,
    String? teamId,
    bool includeArchived = false,
  }) {
    return _getStudentsStreamUseCase(
      actor: actor,
      teamId: teamId,
      includeArchived: includeArchived,
    );
  }

  Future<StudentModel?> findById(String docId, {bool includeArchived = false}) {
    return _repository.getStudentById(docId, includeArchived: includeArchived);
  }

  // FIX [008]: Offset-count page fetch for load-more pagination. (T008)
  // Uses count-based approach (offset via limit) since the repository returns
  // models, not raw DocumentSnapshots. Acceptable for P3 scale.
  Future<StudentsPage> fetchPage({
    required AuthUser actor,
    int limit = 20,
    int offset = 0,
    String? teamId,
    bool includeArchived = false,
  }) async {
    // Fetch (offset + limit + 1) items and skip the first `offset`
    // to simulate forward paging without a raw DocumentSnapshot cursor.
    final all = await _repository.getAllStudents(
      limit: offset + limit + 1,
      includeArchived: includeArchived,
    );
    final page = all.skip(offset).take(limit).toList(growable: false);
    final hasMore = all.length > offset + limit;
    return StudentsPage(students: page, hasMore: hasMore);
  }
}

/// Result of a single page fetch for student pagination.
// FIX [008]: Simple value holder for paginated student results. (T008)
class StudentsPage {
  const StudentsPage({required this.students, required this.hasMore});

  final List<StudentModel> students;
  final bool hasMore;
}

import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/models/attendance_record.dart';

class ReportRepository {
  final FirebaseFirestore _firestore;

  ReportRepository({required FirebaseFirestore firestore})
      : _firestore = firestore;

  Future<List<AttendanceRecord>> fetchAllRecords() async {
    final snapshot = await _firestore
        .collection('attendance')
        .orderBy('timestamp', descending: true)
        .limit(10000)
        .get();

    return snapshot.docs.map((doc) {
      return AttendanceRecord(
        id: doc.id,
        sessionId: doc.data()['sessionId'] as String,
        studentId: doc.data()['studentId'] as String,
        isPresent: doc.data()['isPresent'] as bool,
        timestamp: doc.data()['timestamp'] as String,
        syncStatus: doc.data()['syncStatus'] as String? ?? 'synced',
      );
    }).toList();
  }
}

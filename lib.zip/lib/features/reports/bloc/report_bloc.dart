import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/models/attendance_record.dart';
import 'report_state.dart';
import 'report_repository.dart';

class ReportBloc extends Bloc<ReportEvent, ReportState> {
  final ReportRepository _repository;

  ReportBloc({required ReportRepository repository})
      : _repository = repository,
        super(ReportLoading()) {
    on<LoadMonthlyReportEvent>(_onLoadMonthlyReport);
  }

  Future<void> _onLoadMonthlyReport(
    LoadMonthlyReportEvent event,
    Emitter<ReportState> emit,
  ) async {
    emit(ReportLoading());

    try {
      final records = await _repository.fetchAllRecords();

      if (records.isEmpty) {
        emit(ReportEmpty());
        return;
      }

      // Calculate monthly statistics in BLoC
      final monthlyStats = _calculateMonthlyStats(records);
      emit(ReportLoaded(monthlyStats: monthlyStats));
    } catch (e) {
      emit(ReportError(message: e.toString()));
    }
  }

  List<MonthlyStat> _calculateMonthlyStats(List<AttendanceRecord> records) {
    final grouped = <String, List<AttendanceRecord>>{};

    for (var record in records) {
      final monthKey = record.timestamp.substring(0, 7); // YYYY-MM
      grouped.putIfAbsent(monthKey, () => []);
      grouped[monthKey]!.add(record);
    }

    return grouped.entries.map((entry) {
      final total = entry.value.length;
      final present = entry.value.where((r) => r.isPresent).length;
      final percentage = (present / total * 100).round();
      return MonthlyStat(month: entry.key, total: total, present: present, percentage: percentage);
    }).toList()
      ..sort((a, b) => a.month.compareTo(b.month));
  }
}

class LoadMonthlyReportEvent {}

class MonthlyStat {
  final String month;
  final int total;
  final int present;
  final int percentage;

  MonthlyStat({
    required this.month,
    required this.total,
    required this.present,
    required this.percentage,
  });
}

class ReportState {
  const ReportState();
}

class ReportLoading extends ReportState {}

class ReportEmpty extends ReportState {}

class ReportLoaded extends ReportState {
  final List<MonthlyStat> monthlyStats;

  ReportLoaded({required this.monthlyStats});
}

class ReportError extends ReportState {
  final String message;

  ReportError({required this.message});
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'report_bloc.dart';
import '../../core/models/attendance_record.dart';

class MonthlyReportScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Monthly Report')),
      body: BlocProvider(
        create: (context) => ReportBloc(),
        child: BlocBuilder<ReportBloc, ReportState>(
          builder: (context, state) {
            if (state is ReportLoading) {
              return Center(child: CircularProgressIndicator());
            }

            if (state is ReportEmpty) {
              return Center(child: Text('No data available'));
            }

            if (state is ReportLoaded) {
              return ListView.builder(
                itemCount: state.monthlyStats.length,
                itemBuilder: (context, index) {
                  final stat = state.monthlyStats[index];
                  return ListTile(
                    title: Text('Month: ${stat.month}'),
                    subtitle: Text('Attendance: ${stat.percentage}%'),
                  );
                },
              );
            }

            return Center(child: Text('Error loading report'));
          },
        ),
      ),
    );
  }
}

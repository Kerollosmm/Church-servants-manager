import 'package:church_management_system/core/constants/enums.dart';
import 'package:church_management_system/core/routing/route_args.dart';
import 'package:church_management_system/core/theme/app_spacing.dart';
import 'package:church_management_system/core/widgets/feedback/app_snackbars.dart';
import 'package:church_management_system/features/servant/data/models/servant_models.dart';
import 'package:church_management_system/features/servant/presentation/bloc/servant_data/servant_data_cubit.dart';
import 'package:church_management_system/features/servant/presentation/widgets/servant_edit_form_sections.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AddEditServantScreen extends StatefulWidget {
  const AddEditServantScreen({super.key, required this.args});

  final ServantEditArgs args;

  @override
  State<AddEditServantScreen> createState() => _AddEditServantScreenState();
}

class _AddEditServantScreenState extends State<AddEditServantScreen> {
  final _formKey = GlobalKey<FormState>();

  late final _ServantEditControllers _controllers;
  late Group _selectedGroup;
  late UserRole _selectedRole;
  DateTime? _birthdate;

  @override
  void initState() {
    super.initState();
    final servant = widget.args.servant;
    _controllers = _ServantEditControllers.fromServant(servant);
    _birthdate = servant?.birthdate;
    _selectedRole = servant?.role ?? UserRole.servant;
    _selectedGroup = Group.values.firstWhere(
      (value) => value.name == servant?.teamName,
      orElse: () => Group.year1,
    );
  }

  @override
  void dispose() {
    _controllers.dispose();
    super.dispose();
  }

  Future<void> _pickBirthdate() async {
    final now = DateTime.now();
    final initial = _birthdate ?? DateTime(now.year - 25, now.month, now.day);
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(1950),
      lastDate: now,
      initialDate: initial,
    );
    if (selected != null) {
      setState(() => _birthdate = selected);
    }
  }

  String? _passwordValidator(String? value) {
    return value == null || value.length < 6
        ? 'يجب أن تكون 6 أحرف على الأقل'
        : null;
  }

  String? _nullableTrimmed(String value) {
    final trimmed = value.trim();
    return trimmed.isEmpty ? null : trimmed;
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final actor = widget.args.actor;
    final isEditing = widget.args.isEditing;
    final existing = widget.args.servant;

    final servant = ServantModel(
      uid: existing?.uid,
      docID: existing?.docID ?? 'temp',
      name: _controllers.name.text.trim(),
      phone: _nullableTrimmed(_controllers.phone.text),
      email: _nullableTrimmed(_controllers.email.text),
      imageUrl: _nullableTrimmed(_controllers.imageUrl.text),
      role: isEditing ? _selectedRole : UserRole.servant,
      teamName: _selectedGroup.name,
      fatherOfConfession: _nullableTrimmed(
        _controllers.fatherOfConfession.text,
      ),
      birthdate: _birthdate,
      notes: _nullableTrimmed(_controllers.notes.text),
    );

    final cubit = context.read<ServantDataCubit>();
    if (isEditing) {
      cubit.updateServant(actor: actor, servant: servant);
      return;
    }

    cubit.createServant(
      actor: actor,
      servant: servant,
      email: _nullableTrimmed(_controllers.email.text),
      password: _nullableTrimmed(_controllers.password.text),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.args.isEditing;

    return BlocListener<ServantDataCubit, ServantDataState>(
      listener: (context, state) {
        if (state is ServantDataLoaded &&
            state.mutationStatus == ServantMutationStatus.success &&
            state.feedbackMessage != null) {
          Navigator.pop(context);
        } else if (state is ServantDataError) {
          AppSnackbars.showError(context, state.message);
        } else if (state is ServantDataLoaded &&
            state.mutationStatus == ServantMutationStatus.failure &&
            state.feedbackMessage != null) {
          AppSnackbars.showError(context, state.feedbackMessage!);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text(isEditing ? 'تعديل خادم' : 'إضافة خادم')),
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(AppSpacing.md),
              children: [
                ServantPrimaryDetailsSection(
                  nameController: _controllers.name,
                  phoneController: _controllers.phone,
                  emailController: _controllers.email,
                  passwordController: _controllers.password,
                   isEditing: isEditing,
                   selectedRole: _selectedRole,
                   selectedGroup: _selectedGroup,
                   onRoleChanged: (value) {
                     setState(() => _selectedRole = value);
                   },
                   onGroupChanged: (value) {
                     setState(() => _selectedGroup = value);
                   },
                   passwordValidator: _passwordValidator,
                 ),
                AppSpacing.gapMd,
                ServantSecondaryDetailsSection(
                  fatherOfConfessionController:
                      _controllers.fatherOfConfession,
                  notesController: _controllers.notes,
                  imageUrlController: _controllers.imageUrl,
                  birthdate: _birthdate,
                  onPickBirthdate: _pickBirthdate,
                ),
                AppSpacing.gapMd,
                BlocBuilder<ServantDataCubit, ServantDataState>(
                  builder: (context, state) {
                    final isSubmitting = state is ServantDataLoading ||
                        (state is ServantDataLoaded &&
                            state.mutationStatus ==
                                ServantMutationStatus.inProgress);
                    return FilledButton.icon(
                      onPressed: isSubmitting ? null : _submit,
                      icon: isSubmitting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Icon(isEditing ? Icons.save_outlined : Icons.add),
                      label: Text(isEditing ? 'حفظ التعديلات' : 'إنشاء خادم'),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ServantEditControllers {
  _ServantEditControllers({
    required this.name,
    required this.phone,
    required this.email,
    required this.password,
    required this.fatherOfConfession,
    required this.notes,
    required this.imageUrl,
  });

  factory _ServantEditControllers.fromServant(ServantModel? servant) {
    return _ServantEditControllers(
      name: TextEditingController(text: servant?.name ?? ''),
      phone: TextEditingController(text: servant?.phone ?? ''),
      email: TextEditingController(text: servant?.email ?? ''),
      password: TextEditingController(),
      fatherOfConfession: TextEditingController(
        text: servant?.fatherOfConfession ?? '',
      ),
      notes: TextEditingController(text: servant?.notes ?? ''),
      imageUrl: TextEditingController(text: servant?.imageUrl ?? ''),
    );
  }

  final TextEditingController name;
  final TextEditingController phone;
  final TextEditingController email;
  final TextEditingController password;
  final TextEditingController fatherOfConfession;
  final TextEditingController notes;
  final TextEditingController imageUrl;

  void dispose() {
    name.dispose();
    phone.dispose();
    email.dispose();
    password.dispose();
    fatherOfConfession.dispose();
    notes.dispose();
    imageUrl.dispose();
  }
}
